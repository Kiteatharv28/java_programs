  

  class Operators{

	  public static void main(String [] args){

		  int x=4;
		  int y=5;
         	  int z=6;

		  int ans=x+y*z+(x-y);
		  System.out.println(ans);

	  }
  }

	  
