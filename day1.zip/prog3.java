

class Relational{
        
         public static void main(String []args){

		 int x=10;
		 int y=30;


		 System.out.println(x<y);
		 System.out.println(x>y);
		 System.out.println(x<=y);
		 System.out.println(x>=y);
		 System.out.println(x==y);
		 System.out.println(x!=y);

	 }
}
