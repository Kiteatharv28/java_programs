class Logical{

	public static void main(String [] args){

		int x=6;

		int y=20;

		boolean ans1=x<y && y<x;
		boolean ans2=x<y || y<x;

		System.out.println(ans2);

                System.out.println(ans1);

	}
}
