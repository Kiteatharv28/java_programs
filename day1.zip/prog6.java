class Bitwise{

	public static void main(String [] args){

		int x=8;
		int y=10;

		System.out.println(x&y);
		System.out.println(x|y);
		System.out.println(x^y);

	}
}
