class Bitwise{

	public static void main(String [] args){

		int x=8;

		int y=20;

		System.out.println(x<<2);
		System.out.println(y>>2);

	}
}


