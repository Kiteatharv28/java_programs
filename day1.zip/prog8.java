class Bitwise{

	public static void main(String [] args){

		int x=7;
		  
		System.out.println(x>>2);
		System.out.println(x>>>3);

	}
}
