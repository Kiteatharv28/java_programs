class Division{
	public static void main(String [] args){

		int x=20;

		if(x%4==0){

			System.out.println(x +"is divisible by 4");

		}
		else{
			System.out.println("is not divisible by 4");
		}
	}
}
