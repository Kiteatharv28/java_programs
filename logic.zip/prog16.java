class Bills{
   public static void main(String [] args){

	   int x=150;
	   if(x<=100){
		   System.out.println(x*1);

	   }
	   else if(x>100){

		   System.out.println(x*1+(x-100)*2);

	   }
   }
}


