class switchDemo{

	public static void main(String [] args){

		switch(x){

			case 1:
				System.out.println("1");
				break;
			case 2:
				System.out.println("2");
				break;
			case 1+2:
                                System.out.Println("First-5");
                                break;
			case 5:
				System.out.println("second 5");
				break;
			case 2:
				System.out.println("Second 2");
				break;
			default:
				System.out.println("no Match");
		}
	}
}
