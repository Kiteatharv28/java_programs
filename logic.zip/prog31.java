class Switchdemo{

	public static void main(string [] args){

		int ch=65;

		switch(ch){

			case'A':
				System.out.println("Char A");
				break;

			case 65:
				System.out.println("Num-6");
				break;
			case 'B':
				System.out.println("char B");
				break;
			case 66:
				System.out.println("Num -66");
				break;
			default:
				System.out.println("Invalid");
		}
	}
}





