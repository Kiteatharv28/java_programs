class Compare{
     public static void main(String [] args){

	     int x=5;
	     int y=7;

	     if(x>y){

		     System.out.println(x+ "is greater");

	     }
	     else{
		     System.out.println(y+ "is greater");
	     }
     }
}

